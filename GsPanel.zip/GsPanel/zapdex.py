import pyodbc
from datetime import datetime, timedelta
import time
import pyautogui
import base64
import os
from email.mime.text import MIMEText
from requests import HTTPError
import os.path
import schedule
import smtplib
from email.mime.multipart import MIMEMultipart
import subprocess
import string
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.ui import WebDriverWait
from webdriver_manager.chrome import ChromeDriverManager
import wmi
import jaydebeapi

os.system("color 0E")

server = '192.168.100.10'
database = 'PBS_NISSEI_DADOS'
username = 'procfit.lojas'
password = 'Pr0cf1t#Lojas!$P%r'
loop_interval_seconds = 600

connection_string = f'DRIVER=SQL Server;SERVER={server};DATABASE={database};UID={username};PWD={password}'

def auto_sub():
     #       
     # Informações de conexão
     server = '192.168.200.96'
     port = '24011'
     database = 'custom'
     username = 'procfit'
     password = 'procfit'
     driver_jar_path = 'OpenEdge.jar'

     # Configurações para acesso ao servidor remoto
     remote_host = '192.168.200.150'  # IP do servidor remoto
     remote_username = 'svc_procfit'
     remote_password = 'Pr0cf17@2017!@#'
     service_name = 'PROCFIT ORACLE INTEGRETION'  # Nome do serviço a ser reiniciado no Windows

     # String de conexão JDBC
     connection_string = f'jdbc:datadirect:openedge://{server}:{port};databaseName={database}'
     try:
       # Carregar o driver usando o JayDeBeApi
       connection = jaydebeapi.connect(
       "com.ddtek.jdbc.openedge.OpenEdgeDriver",
       connection_string,
       [username, password],
       driver_jar_path
       )
     
       # Criar um cursor para executar comandos SQL
       cursor = connection.cursor()

       # Consulta SQL
       query = '''
         SELECT * FROM pub."int_ds_cliente"
         WHERE ENVIO_STATUS = 1 AND ORIGEM_CLI = 3 AND ID_SEQUENCIAL > 0
       '''
     except Exception as e:
            snife9r = str(e)
            print(snife9r) 
     try:
         # Executar a consulta
         cursor.execute(query)
         bang = cursor.fetchall()
         if bang:
           
            print("nenhum erro")
            c = wmi.WMI(computer=remote_host, user=remote_username, password=remote_password)
            for service in c.Win32_Service(Name=service_name):
                if service.State == 'Running':
                    service.StopService()
                    print(f"O serviço {service_name} foi parado no servidor {remote_host}")
                    time.sleep(2)
                    service.StartService()
                    print(f"O serviço {service_name} foi iniciado no servidor {remote_host}")
                    
                else:
                   service.StartService()
                   print(f"O serviço {service_name} foi iniciado no servidor {remote_host}")
                             
            return 5
            
     except Exception as e:
            snifer = str(e)
            print(snifer)
            
            #snifer = "endereco"
      
            if 'endereco' in snifer:  # Verificar erro de endereço
                     update_query = '''
                         UPDATE PUB.INT_DS_CLIENTE SET endereco = SUBSTR(endereco, 1, 80)
                         WHERE ENVIO_STATUS = 1 AND ORIGEM_CLI = 3 AND ID_SEQUENCIAL > 0
                     '''
                     cursor.execute(update_query)
                     connection.commit()
                     return 1
                     
            elif 'nome_emit' in snifer:  # Verificar erro de nome_emit
                     update_query = '''
                         UPDATE PUB.INT_DS_CLIENTE SET nome_emit = SUBSTR(nome_emit, 1, 80)
                         WHERE ENVIO_STATUS = 1 AND ORIGEM_CLI = 3 AND ID_SEQUENCIAL > 0
                     '''
                     cursor.execute(update_query)
                     conn.commit()
                     return 2
            else:
                     # Se não encontrar nenhum erro especificado
                     # Reiniciar o serviço no servidor Windows remotamente
                     c = wmi.WMI(computer=remote_host, user=remote_username, password=remote_password)
                     for service in c.Win32_Service(Name=service_name):
                         if service.State == 'Running':
                             service.StopService()
                             print(f"O serviço {service_name} foi parado no servidor {remote_host}")
                             time.sleep(2)
                             service.StartService()
                             print(f"O serviço {service_name} foi iniciado no servidor {remote_host}")
                             return 3
                         else:
                             service.StartService()
                             print(f"O serviço {service_name} foi iniciado no servidor {remote_host}")
                             return 4       
            
    

  
     connection.close()


def enviar_email(name):
    remetente = "chamados.suporte@nisseisa.com.br"
    destinatarios = ['michael.alexandria@nisseisa.com.br', 'eduardo.junior@nisseisa.com.br', 'carlos.filho@nisseisa.com.br', 'rodrigo.machado@nisseisa.com.br', 'joao.novitzki@nisseisa.com.br', 'lincoln.pereira@nisseisa.com.br', 'william.peixoto@nisseisa.com.br']


    # Configurar a mensagem
    msg = MIMEMultipart('alternative')
    msg['Subject'] = "🥲 Alerta!!! Notas do ecommerce pararam de integrar!!!!"
    msg['From'] = remetente
    msg['To'] = ", ".join(destinatarios)

    # Criar o corpo da mensagem (versão em texto simples e em HTML)
    texto = "🥲 Alerta!!! Notas do ecommerce pararam de integrar!!!!"
    html = f'''
        <div style="background-color: rgba(128, 0, 128, 0.8); padding: 15px; border-radius: 10px; box-shadow: 0 0 20px rgba(128, 0, 128, 0.5), 0 0 50px rgba(128, 0, 128, 0.2); display: flex; align-items: center;">
            <div style="flex: 1; padding-right: 1px;">
                <h1 style="color: #00eaff;">Alerta!</h1>
                <p style="font-size: 20px; color: white; font-weight: bold; margin-top: 1px;">Notas fiscais do e-commerce não integram há {name}.</p>
                <p style="font-size: 18px; color: white; margin-top: 1px;">"Parece Que Vamos Ter Que Apelar!"</p>
            </div>
            <div class="image" style="margin-left: 1px;">
                <img src="https://raw.githubusercontent.com/Mikehzin/datasync/1b10611a4e1890f4f6cba05862a80b8350aa37b6/cyber.png" alt="Garoto Cyber" style="max-width: 180px; height: auto; border-radius: 10px; filter: brightness(1.2) saturate(1.5);" />
            </div>
        </div>
    '''

    # Configurar partes da mensagem
    parte_texto = MIMEText(texto, 'plain')
    parte_html = MIMEText(html, 'html')

    msg.attach(parte_texto)
    msg.attach(parte_html)

    # Enviar o e-mail via servidor SMTP local
    servidor_smtp = smtplib.SMTP('smtp.skymail.net.br', 587)
    servidor_smtp.ehlo()
    servidor_smtp.starttls()
    servidor_smtp.login('chamados.suporte@nisseisa.com.br', '1hL4qS7f8Ga8Du9Oy3')
    servidor_smtp.sendmail(remetente, destinatarios, msg.as_string())
    servidor_smtp.quit()

def send_zap(name, lapse, cell, autox):
       BASE_URL = "https://web.whatsapp.com/"
       CHAT_URL = "https://web.whatsapp.com/send?phone={phone}&text&type=phone_number&app_absent=1"


       # Resto do seu código
       chrome_options = Options()
       chrome_options.add_argument("start-maximized")
       #user_data_dir = ''.join(random.choices(string.ascii_letters, k=8))
       user_data_dir = 'Robot.v1'
       chrome_options.add_argument("--user-data-dir=c:/Users/michael.alexandria/documents/" + user_data_dir)
       #chrome_options.add_argument("--incognito")

       browser = webdriver.Chrome(options=chrome_options)

       browser.get(BASE_URL)
       browser.maximize_window()

       phone = cell
       print(f"o autox é {autox}")
       if autox == 2:
          message = f"Olá {name}, Identifiquei um problema com cliente que travou a integração das NF e-commerce e já corrigi.. logo as notas voltaram a integrar!"
       elif autox == 1:
          message = f"Olá {name}, Identifiquei um endereço invalido que travou a integração das NF e-commerce e já corrigi.. logo as notas voltaram a integrar!" 
       elif autox == 5:     
          message = f"Olá {name}, As Notas fiscais do e-commerce não integram há {lapse}, já verifiquei problemas com clientes/endereço e reiniciei o serviço ORACLE"
       elif autox == 4:
          message = f"Olá {name}, Identifiquei que o serviço ORACLE estava inativo e iniciei o mesmo.. Aguardar..."
       else:
          message = f"Olá {name}, As Notas fiscais do e-commerce não integram há {lapse}"
          
       browser.get(CHAT_URL.format(phone=phone))
       time.sleep(5)


       inp_xpath = (
           '//*[@id="main"]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[1]'
       )
       
       try:
          input_box = WebDriverWait(browser, 300).until(
                expected_conditions.presence_of_element_located((By.XPATH, inp_xpath))
          )
          input_box.send_keys(message)
          input_box.send_keys(Keys.ENTER)
          time.sleep(20)
          
       except Exception as e:
        print(f"Erro ao enviar mensagen: {e}")
               

def check_and_send_message():
    try:
        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()

        cursor.execute("""
        DECLARE @DATA DATE
        SET @DATA = GETDATE()
        SELECT TOP 1 DATA_HORA FROM NF_FATURAMENTO WHERE NF_SERIE = '402' AND CONVERT(date, DATA_HORA) = @DATA
        ORDER BY DATA_HORA DESC""")

        row = cursor.fetchone()
        cursor.close()
        conn.close()

        if row:
            now = datetime.now().replace(microsecond=0)

            db_datetime_str = str(row[0].replace(microsecond=0))
            db_datetime = datetime.strptime(db_datetime_str, '%Y-%m-%d %H:%M:%S')

            max_minutes_difference = 30

            contigencia_seconds = (now - db_datetime).total_seconds()

            if contigencia_seconds >= 7200:
                contigencia_str = f"{int(contigencia_seconds / 3600)} {'hora' if int(contigencia_seconds / 3600) == 1 else 'horas'}"
            else:
                minutos = int(contigencia_seconds / 60)
                if minutos >= 60:
                    horas = minutos // 60
                    minutos %= 60
                    contigencia_str = f"{horas} {'hora' if horas == 1 else 'horas'}"
                    if minutos > 0:
                       contigencia_str += f" {minutos} {'minuto' if minutos == 1 else 'minutos'}"
                elif minutos > 0:
                    contigencia_str = f"{minutos} {'minuto' if minutos == 1 else 'minutos'}"
                else:
                    contigencia_str = f"{int(contigencia_seconds)} {'segundo' if contigencia_seconds == 1 else 'segundos'}"

            if contigencia_seconds > max_minutes_difference * 60:
                    autox = auto_sub()                           
                
                    cell = "+5541991262078"
                    name = "Mikezao"
                    lapse = str(contigencia_str)
                    send_zap(name, lapse, cell, autox)
                    time.sleep(10)
                
                
                    cell = "+554184346295"
                    name = "Hiago"
                    lapse = str(contigencia_str)
                    print("Pararam de integrar")
                    send_zap(name, lapse, cell, autox)
                
                    #time.sleep(10)  # Aguarde 5 segundos antes de fechar o navegador

                    #cell = "+5541988777798"
                    #name = "Lincoln"
                    #print("Pararam de integrar")
                    #send_zap(name, lapse, cell, autox)                
                    time.sleep(10)
                
                    cell = "+554187943175"
                    name = "Meu Caro"
                    send_zap(name, lapse, cell, autox)
                
                    time.sleep(10)                
               
                    cell = "+554187478142"
                    name = "Meu Caro"
                    send_zap(name, lapse, cell, autox)
                    time.sleep(10) 

                    cell = "+554187478390"
                    name = "Peixotinho"
                    send_zap(name, lapse, cell, autox)
                    time.sleep(10)                    
                              
                    enviar_email(contigencia_str)


            else:
                print("Notas estão integrando normalmente, Ultima Integração foi há", contigencia_str," <--")

        else:
            print("Nenhum registro encontrado para a data de hoje.")
    except (pyodbc.OperationalError, pyodbc.Error) as e:        
        print(f"Erro ao acessar o servidor!")



while True:
    schedule.run_pending()
    current_time = datetime.now().time()
    if current_time >= datetime.strptime("7:00", "%H:%M").time() and current_time <= datetime.strptime("23:00", "%H:%M").time():
      check_and_send_message()
      time.sleep(loop_interval_seconds)
    else:
        print("Robo Descansando, Começa trabalhar as 7h até as 23h")
        time.sleep(30)
